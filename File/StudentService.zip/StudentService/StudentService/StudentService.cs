﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace StudentService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "StudentService" in both code and config file together.
    public class StudentService : IStudentService
    {
        public string GetStudentInfo(int studentId)
        {
            string studentName = string.Empty;
            switch (studentId)
            {
                case 1:
                    {
                        studentName = "Muhammad Ahmad";
                        break;
                    }
                case 2:
                    {
                        studentName = "Muhammad Hamza";
                        break;
                    }
                default:
                    {
                        studentName = "No student found";
                        break;
                    }
            }
            return studentName;
        }

        public string EchoWithGet(string s)
        {
            return "You said " + s;
        }
        public System.IO.Stream Connect(string s)
        {
            string result = "<a href='someLingk' >Some link</a>";
            byte[] resultBytes = Encoding.UTF8.GetBytes(result);
            WebOperationContext.Current.OutgoingResponse.ContentType = "text/html";
            WebOperationContext.Current.OutgoingResponse.Headers.Add("Access-Control-Allow-Origin", "*");
           // AddHeader("Access-Control-Allow-Origin", "*");
           // Add(System.Net.HttpRequestHeader.Allow, "*");
                //.AppendHeader("Access-Control-Allow-Origin", "*");
            return new MemoryStream(resultBytes);
        }

        public System.IO.Stream ConnectPost(Stream request)
        {
            StreamReader reader = new StreamReader(request);
            string text = " " + reader.ReadToEnd();
            Console.WriteLine("Text = :" + text);
            //System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();
            string result = "<a href='someLingk' >Some link</a>";
            byte[] resultBytes = Encoding.UTF8.GetBytes(result);
            WebOperationContext.Current.OutgoingResponse.ContentType = "text/html";
            WebOperationContext.Current.OutgoingResponse.Headers.Add("Access-Control-Allow-Origin", "*");
            //Console.WriteLine("this link has been executed.");
            return new MemoryStream(resultBytes);
        }

    }
}
